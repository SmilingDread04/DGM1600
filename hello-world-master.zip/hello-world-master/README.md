# hello-world
My first repository class assignment
My name is Connor and this is the very first time I've ever created something via the coding method and I,
hopefully, will have a fun time and learn what I need to be a game developer.
